package com.example.user.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private Button add;
    private Button sub;
    private Button mul;
    private Button div;
    private EditText e1;
    private EditText e2;
    private TextView t1;

    private void init(){
        add = (Button)findViewById(R.id.button);
        sub = (Button)findViewById(R.id.button2) ;
        mul = (Button)findViewById(R.id.button3);
        div = (Button)findViewById(R.id.button4);
        e1 = (EditText)findViewById(R.id.editText2);
        e2 = (EditText)findViewById(R.id.editText3);
        t1 = (TextView)findViewById(R.id.editText);

        add.setOnClickListener(this);
        sub.setOnClickListener(this);
        mul.setOnClickListener(this);
        div.setOnClickListener(this);
    }



    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.button:
                int num1 = Integer.parseInt(e1.getText().toString());
                int num2 = Integer.parseInt(e2.getText().toString());
                int sum = num1 + num2;
                t1.setText(Integer.toString(sum));
                break;
            case R.id.button2:
                int sb = Integer.parseInt(e1.getText().toString()) - Integer.parseInt(e2.getText().toString());
                t1.setText(Integer.toString(sb));
                break;
            case R.id.button3:
                int multiply = Integer.parseInt(e1.getText().toString()) * Integer.parseInt(e2.getText().toString());
                t1.setText(Integer.toString(multiply));
                break;
            case R.id.button4:
                try {
                    int division = Integer.parseInt(e1.getText().toString()) / Integer.parseInt(e2.getText().toString());
                    t1.setText(Integer.toString(division));
                }catch (Exception e){
                    t1.setText("Can't divided!");
                }
                break;
        }

    }
}
